module.exports = {
    purge: [
        './resources/views/**/*.php',
        './resources/views/**/*.html',
        './resources/assets/js/**/*.vue',
        './resources/content/**/*.html'
    ],
    theme: {},
    variants: {},
    plugins: [],
}